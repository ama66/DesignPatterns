list = [1,2,3]
for i in list:
    print(i)
iter = list.__iter
iter.__next__()
