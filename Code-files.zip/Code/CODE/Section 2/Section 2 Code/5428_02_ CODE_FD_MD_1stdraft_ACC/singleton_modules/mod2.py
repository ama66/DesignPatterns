from singleton_modules import a_single_var

print(a_single_var.only_one)
